/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Bill, Category, UserSettings } from './types';
import { api, loadBills, loadSettings } from './mockData';
import HomeView from './components/HomeView';
import BillsView from './components/BillsView';
import MyView from './components/MyView';
import StatsView from './components/StatsView';
import TabBar from './components/TabBar';

export default function App() {
  const userEmail = 'hyq422906@gmail.com';
  const [activeTab, setActiveTab] = useState<'home' | 'bills' | 'my' | 'stats'>('home');
  const [previousTab, setPreviousTab] = useState<'home' | 'bills' | 'my'>('home');
  const [bills, setBills] = useState<Bill[]>([]);
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [loading, setLoading] = useState(true);

  // Custom elegant toast notification state
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  // Load initial data
  useEffect(() => {
    async function init() {
      setLoading(true);
      try {
        const loadedBills = await api.getBills('2026'); // load all bills for year 2026
        const loadedSettings = await api.getSettings();
        
        // If nothing came from api, use fallback synchronous loaders
        setBills(loadedBills.length > 0 ? loadedBills : loadBills());
        setSettings(loadedSettings || loadSettings());
      } catch (err) {
        console.error('Failed to load initial data:', err);
        // Fallback to local storage directly
        setBills(loadBills());
        setSettings(loadSettings());
      } finally {
        setLoading(false);
      }
    }
    init();
  }, []);

  // Show a visual toast notification
  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 3000);
  };

  // Add bill handler
  const handleAddBill = async (billData: Omit<Bill, 'id' | 'createTime'>) => {
    try {
      const newBill = await api.addBill(billData);
      setBills((prev) => [newBill, ...prev]);
      showToast('账单记录保存成功！', 'success');
    } catch (err) {
      console.error('Failed to add bill:', err);
      showToast('账单保存失败，请重试！', 'error');
    }
  };

  // Delete bill handler
  const handleDeleteBill = async (id: string) => {
    if (window.confirm('您确定要删除这笔账单记录吗？')) {
      try {
        await api.deleteBill(id);
        setBills((prev) => prev.filter((b) => b.id !== id));
        showToast('账单记录已成功删除', 'info');
      } catch (err) {
        console.error('Failed to delete bill:', err);
        showToast('删除失败，请重试！', 'error');
      }
    }
  };

  // Update settings handler (budget / custom categories)
  const handleUpdateSettings = async (newSettings: UserSettings) => {
    try {
      const updated = await api.updateSettings(newSettings);
      setSettings(updated);
      showToast('设置更新成功', 'success');
    } catch (err) {
      console.error('Failed to update settings:', err);
      showToast('设置更新失败，请重试！', 'error');
    }
  };

  // Tab switching wrapper that remembers non-stats tab
  const handleTabChange = (tab: 'home' | 'bills' | 'my') => {
    setActiveTab(tab);
    setPreviousTab(tab);
  };

  const handleNavigateToStats = () => {
    setActiveTab('stats');
  };

  const handleBackFromStats = () => {
    setActiveTab(previousTab);
  };

  if (loading || !settings) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-slate-50 space-y-3">
        <div className="h-10 w-10 animate-spin rounded-full border-4 border-emerald-500 border-t-transparent" />
        <p className="text-xs font-semibold text-slate-500 animate-pulse">正在加载记账本数据...</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen w-screen bg-[#f8fafc] text-slate-800 font-sans overflow-hidden">
      
      {/* Top Professional Workbench Header - Hidden on small mobile screens to save space */}
      <header className="hidden md:flex h-14 border-b border-slate-200 bg-white items-center justify-between px-6 shrink-0 shadow-sm z-10">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center text-white font-bold shadow-xs">U</div>
          <div className="flex flex-col">
            <h1 className="font-semibold text-sm leading-tight text-slate-800">
              记账小工具 <span className="text-slate-400 font-normal text-xs ml-2">uni-app & uni-ui 开发工作台 v1.0.0</span>
            </h1>
            <span className="font-mono text-[9px] text-slate-400">项目路径: F:\Ayanjiusuo\hx\uniapp\jishiben\front\</span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex bg-slate-100 p-0.5 rounded-lg text-xs font-semibold">
            <button 
              onClick={() => showToast('模拟 H5 热更新成功', 'info')}
              className="px-3 py-1 bg-white rounded-md shadow-xs text-slate-800 cursor-pointer"
            >
              H5 端预览
            </button>
            <button 
              onClick={() => showToast('微信开发者工具已同步联动', 'info')}
              className="px-3 py-1 text-slate-400 hover:text-slate-700 cursor-pointer"
            >
              微信小程序端
            </button>
          </div>
          <button 
            onClick={() => showToast('项目重新打包编译中...', 'success')}
            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-xs"
          >
            全量编译项目
          </button>
        </div>
      </header>

      {/* Main split workarea */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Left Sidebar - File list & uni-ui lists. Hidden on mobile, visible on desktop */}
        <aside className="hidden lg:flex w-64 border-r border-slate-200 bg-slate-50/50 flex-col shrink-0">
          {/* Files Explorer Section */}
          <div className="p-4 border-b border-slate-100 bg-white">
            <div className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 mb-2.5">
              项目目录 (Project Explorer)
            </div>
            <div className="space-y-1 font-sans">
              <div className="flex items-center gap-2 p-1.5 text-xs font-bold text-slate-700 rounded-lg hover:bg-slate-200/50 transition-colors">
                <span className="text-sky-500">📁</span> pages
              </div>
              
              <div 
                onClick={() => handleTabChange('home')}
                className={`flex items-center justify-between p-1.5 pl-6 text-xs rounded-lg transition-colors cursor-pointer ${
                  activeTab === 'home' 
                    ? 'bg-emerald-50 text-emerald-700 border-l-2 border-emerald-500 font-bold' 
                    : 'text-slate-600 hover:bg-slate-200/50 font-medium'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span>📄</span> home.vue (首页)
                </div>
                {activeTab === 'home' && <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />}
              </div>

              <div 
                onClick={() => handleTabChange('bills')}
                className={`flex items-center justify-between p-1.5 pl-6 text-xs rounded-lg transition-colors cursor-pointer ${
                  activeTab === 'bills' 
                    ? 'bg-emerald-50 text-emerald-700 border-l-2 border-emerald-500 font-bold' 
                    : 'text-slate-600 hover:bg-slate-200/50 font-medium'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span>📄</span> bills.vue (账单页)
                </div>
                {activeTab === 'bills' && <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />}
              </div>

              <div 
                onClick={() => handleTabChange('my')}
                className={`flex items-center justify-between p-1.5 pl-6 text-xs rounded-lg transition-colors cursor-pointer ${
                  activeTab === 'my' 
                    ? 'bg-emerald-50 text-emerald-700 border-l-2 border-emerald-500 font-bold' 
                    : 'text-slate-600 hover:bg-slate-200/50 font-medium'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span>📄</span> my.vue (我的页)
                </div>
                {activeTab === 'my' && <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />}
              </div>

              <div 
                onClick={() => setActiveTab('stats')}
                className={`flex items-center justify-between p-1.5 pl-6 text-xs rounded-lg transition-colors cursor-pointer ${
                  activeTab === 'stats' 
                    ? 'bg-emerald-50 text-emerald-700 border-l-2 border-emerald-500 font-bold' 
                    : 'text-slate-600 hover:bg-slate-200/50 font-medium'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span>📄</span> stats.vue (统计详情)
                </div>
                {activeTab === 'stats' && <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />}
              </div>

              <div className="flex items-center gap-2 p-1.5 text-xs font-bold text-slate-700 rounded-lg hover:bg-slate-200/50 transition-colors">
                <span className="text-sky-500">📁</span> static (静态图标/资源)
              </div>
              <div className="flex items-center gap-2 p-1.5 text-xs text-slate-600 rounded-lg hover:bg-slate-200/50 transition-colors font-medium">
                <span className="text-purple-500">⚙️</span> pages.json (路由表)
              </div>
              <div className="flex items-center gap-2 p-1.5 text-xs text-slate-600 rounded-lg hover:bg-slate-200/50 transition-colors font-medium">
                <span className="text-emerald-500">📄</span> App.vue (入口配置)
              </div>
            </div>
          </div>

          {/* uni-ui components Reference Section */}
          <div className="p-4 overflow-y-auto flex-1 bg-white">
            <div className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 mb-2.5">
              内置 uni-ui 组件 (uni-ui components)
            </div>
            <div className="grid grid-cols-1 gap-2">
              <div className={`p-2.5 border rounded-xl text-xs font-semibold cursor-help transition-all ${activeTab === 'home' ? 'border-emerald-200 bg-emerald-50/20 text-emerald-700' : 'bg-slate-50 hover:border-slate-300'}`}>
                <div className="flex items-center justify-between">
                  <span>uni-card (卡片)</span>
                  {activeTab === 'home' && <span className="text-[9px] bg-emerald-100 text-emerald-800 px-1.5 rounded-md">首页正使用</span>}
                </div>
                <p className="text-[9px] text-slate-400 mt-0.5 font-normal">用于放置月度预算、支出概览等区块</p>
              </div>

              <div className={`p-2.5 border rounded-xl text-xs font-semibold cursor-help transition-all ${activeTab === 'bills' || activeTab === 'my' ? 'border-emerald-200 bg-emerald-50/20 text-emerald-700' : 'bg-slate-50 hover:border-slate-300'}`}>
                <div className="flex items-center justify-between">
                  <span>uni-list (列表)</span>
                  {(activeTab === 'bills' || activeTab === 'my') && <span className="text-[9px] bg-emerald-100 text-emerald-800 px-1.5 rounded-md">账单页正使用</span>}
                </div>
                <p className="text-[9px] text-slate-400 mt-0.5 font-normal">渲染账单记录行与菜单设置列表</p>
              </div>

              <div className={`p-2.5 border rounded-xl text-xs font-semibold cursor-help transition-all ${activeTab === 'bills' ? 'border-emerald-200 bg-emerald-50/20 text-emerald-700' : 'bg-slate-50 hover:border-slate-300'}`}>
                <div className="flex items-center justify-between">
                  <span>uni-search-bar (搜索栏)</span>
                  {activeTab === 'bills' && <span className="text-[9px] bg-emerald-100 text-emerald-800 px-1.5 rounded-md">筛选中</span>}
                </div>
                <p className="text-[9px] text-slate-400 mt-0.5 font-normal">提供便捷的账单关键词、分类实时搜索</p>
              </div>

              <div className="p-2.5 border rounded-xl bg-slate-50 hover:border-slate-300 text-xs font-semibold cursor-help transition-all">
                <div className="flex items-center justify-between">
                  <span>uni-popup (弹出层)</span>
                  <span className="text-[9px] text-slate-400 font-normal">添加账单调用</span>
                </div>
                <p className="text-[9px] text-slate-400 mt-0.5 font-normal">弹出半屏金额分类输入表单抽屉</p>
              </div>

              <div className={`p-2.5 border rounded-xl text-xs font-semibold cursor-help transition-all ${activeTab === 'stats' ? 'border-emerald-200 bg-emerald-50/20 text-emerald-700' : 'bg-slate-50 hover:border-slate-300'}`}>
                <div className="flex items-center justify-between">
                  <span>l-echart (统计图表)</span>
                  {activeTab === 'stats' && <span className="text-[9px] bg-emerald-100 text-emerald-800 px-1.5 rounded-md">激活中</span>}
                </div>
                <p className="text-[9px] text-slate-400 mt-0.5 font-normal">用于渲染每日支出折线图与分类占比饼图</p>
              </div>
            </div>
          </div>
        </aside>

        {/* Center Section: Emulator Stage on wide, full view on small mobile */}
        <section className="flex-1 flex items-center justify-center bg-slate-100/60 p-0 md:p-8 overflow-y-auto">
          
          {/* Simulated Mobile Frame on Desktop */}
          <div className="w-full h-full md:w-[385px] md:h-[780px] md:bg-black md:rounded-[45px] md:border-[10px] md:border-slate-900 relative md:shadow-2xl md:overflow-hidden flex flex-col">
            
            {/* Top Phone notch and status bar - Hidden on small viewport to maximize space */}
            <div className="hidden md:flex absolute top-0 w-full h-7 bg-white items-center justify-between px-6 pt-1 text-[10px] font-bold z-50">
              <span className="font-mono text-slate-700">9:41</span>
              <div className="absolute top-1.5 left-1/2 -translate-x-1/2 w-20 h-4 bg-black rounded-b-xl z-50 pointer-events-none" />
              <div className="flex gap-1.5 text-slate-700 text-[9px] font-mono">
                <span>📶</span>
                <span>5G</span>
                <span>🔋 99%</span>
              </div>
            </div>

            {/* Inner responsive app workspace */}
            <div className="flex-1 bg-slate-50 flex flex-col md:pt-7 overflow-hidden h-full">
              
              {/* Toast Notification Container Inside Emulator */}
              <AnimatePresence>
                {toast && (
                  <motion.div
                    initial={{ opacity: 0, y: -20, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -20, scale: 0.95 }}
                    className="absolute top-12 inset-x-0 z-50 mx-auto max-w-xs px-4"
                  >
                    <div className={`flex items-center space-x-2.5 rounded-xl px-3.5 py-2.5 shadow-md border text-[11px] font-bold ${
                      toast.type === 'success' 
                        ? 'bg-emerald-600 border-emerald-500 text-white' 
                        : toast.type === 'error'
                        ? 'bg-rose-600 border-rose-500 text-white'
                        : 'bg-slate-800 border-slate-700 text-slate-100'
                    }`}>
                      <span>
                        {toast.type === 'success' && '✨'}
                        {toast.type === 'error' && '⚠️'}
                        {toast.type === 'info' && '📝'}
                      </span>
                      <p>{toast.message}</p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Main viewport with motion transitions */}
              <div className="flex-1 overflow-x-hidden relative">
                <AnimatePresence mode="wait">
                  {activeTab === 'home' && (
                    <motion.div
                      key="home"
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 10 }}
                      transition={{ duration: 0.18 }}
                      className="h-full"
                    >
                      <HomeView
                        bills={bills}
                        settings={settings}
                        onAddBill={handleAddBill}
                        onDeleteBill={handleDeleteBill}
                        onNavigateToStats={handleNavigateToStats}
                      />
                    </motion.div>
                  )}

                  {activeTab === 'bills' && (
                    <motion.div
                      key="bills"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.18 }}
                      className="h-full"
                    >
                      <BillsView 
                        bills={bills} 
                        onDeleteBill={handleDeleteBill} 
                      />
                    </motion.div>
                  )}

                  {activeTab === 'my' && (
                    <motion.div
                      key="my"
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -10 }}
                      transition={{ duration: 0.18 }}
                      className="h-full"
                    >
                      <MyView
                        settings={settings}
                        onUpdateSettings={handleUpdateSettings}
                        onNavigateToStats={handleNavigateToStats}
                        userEmail={userEmail}
                      />
                    </motion.div>
                  )}

                  {activeTab === 'stats' && (
                    <motion.div
                      key="stats"
                      initial={{ opacity: 0, scale: 0.98 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.98 }}
                      transition={{ duration: 0.2 }}
                      className="h-full"
                    >
                      <StatsView 
                        onBack={handleBackFromStats} 
                        initialMonth="2026-07"
                      />
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Persistent Bottom Navigation Tab Bar */}
              <TabBar 
                activeTab={activeTab} 
                onChangeTab={handleTabChange} 
              />
            </div>

            {/* Bottom device bar element */}
            <div className="hidden md:block absolute bottom-1 left-1/2 -translate-x-1/2 w-28 h-1 bg-slate-800 rounded-full z-50 pointer-events-none" />
          </div>
        </section>

        {/* Right Sidebar - Component Inspector detailing real-time reactive values */}
        <aside className="hidden xl:flex w-80 border-l border-slate-200 bg-white flex-col shrink-0">
          <header className="p-4 border-b border-slate-200 font-semibold bg-slate-50 text-xs text-slate-700 tracking-wider">
            ⚙️ 实时组件审查器 (Component Inspector)
          </header>
          
          <div className="p-5 flex-grow space-y-6 overflow-y-auto">
            {/* Active module information */}
            <section>
              <h4 className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest mb-2.5">
                当前活跃模块
              </h4>
              <div className="flex items-center gap-2 p-2.5 bg-emerald-50 border border-emerald-100 rounded-xl">
                <span className="font-mono text-xs font-bold text-emerald-700">
                  {activeTab === 'home' && '<uni-card class="home_budget">'}
                  {activeTab === 'bills' && '<uni-list class="bill_scroll_view">'}
                  {activeTab === 'my' && '<uni-list class="my_settings_menu">'}
                  {activeTab === 'stats' && '<l-echart class="recharts_wrapper">'}
                </span>
              </div>
            </section>

            {/* Dynamic Interactive Properties depending on Active View */}
            <section className="space-y-4">
              <h4 className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">
                属性调试与状态反馈
              </h4>
              
              <div className="space-y-4 bg-slate-50/50 p-3.5 border border-slate-100 rounded-2xl">
                {activeTab === 'home' && (
                  <div className="space-y-3">
                    <div className="flex flex-col gap-1">
                      <label className="text-[10px] font-bold text-slate-400">本月预算 (可由此直接修改):</label>
                      <input 
                        type="number" 
                        value={settings.monthlyBudget} 
                        onChange={(e) => handleUpdateSettings({ ...settings, monthlyBudget: Number(e.target.value) })}
                        className="border border-slate-200 focus:border-emerald-500 outline-hidden bg-white rounded-lg px-2.5 py-1.5 text-xs font-mono font-bold"
                      />
                    </div>
                    <div className="flex flex-col gap-0.5 text-xs">
                      <span className="text-[10px] font-bold text-slate-400 block mb-1">本月统计数据摘要:</span>
                      <div className="flex justify-between py-1 border-b border-slate-100 text-slate-600">
                        <span>总账单笔数:</span>
                        <span className="font-mono font-semibold">{bills.filter(b => b.date.startsWith('2026-07')).length} 笔</span>
                      </div>
                      <div className="flex justify-between py-1 border-b border-slate-100 text-slate-600">
                        <span>总月支出:</span>
                        <span className="font-mono font-semibold text-rose-500">
                          ¥{bills.filter(b => b.date.startsWith('2026-07') && b.type === 'expense').reduce((sum, b) => sum + b.amount, 0).toFixed(2)}
                        </span>
                      </div>
                      <div className="flex justify-between py-1 text-slate-600">
                        <span>总月收入:</span>
                        <span className="font-mono font-semibold text-emerald-600">
                          ¥{bills.filter(b => b.date.startsWith('2026-07') && b.type === 'income').reduce((sum, b) => sum + b.amount, 0).toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'bills' && (
                  <div className="space-y-3">
                    <p className="text-[11px] text-slate-500 leading-relaxed font-semibold">
                      列表组件正通过时间排序，并基于类别过滤进行实时分级渲染：
                    </p>
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between p-2 rounded-lg bg-white border border-slate-100">
                        <span className="text-slate-500">分类检索总数:</span>
                        <span className="font-mono font-bold text-slate-700">
                          {settings.categories.length} 类
                        </span>
                      </div>
                      <div className="flex justify-between p-2 rounded-lg bg-white border border-slate-100">
                        <span className="text-slate-500">当月筛选到笔数:</span>
                        <span className="font-mono font-bold text-slate-700">
                          {bills.filter(b => b.date.startsWith('2026-07')).length} 笔
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'my' && (
                  <div className="space-y-3">
                    <div className="flex flex-col gap-1">
                      <label className="text-[10px] font-bold text-slate-400">开发者邮箱 (仅作预览展示):</label>
                      <input 
                        type="text" 
                        readOnly
                        value={userEmail}
                        className="border border-slate-200 outline-hidden bg-slate-100 text-slate-500 rounded-lg px-2.5 py-1.5 text-xs font-mono font-medium"
                      />
                    </div>
                    <div className="space-y-1.5 text-xs">
                      <span className="text-[10px] text-slate-400 font-bold">分类数据一览:</span>
                      <div className="grid grid-cols-2 gap-1.5">
                        <div className="p-2 rounded-xl border border-slate-100 bg-white text-center">
                          <div className="font-mono font-bold text-slate-700">
                            {settings.categories.filter(c => c.type === 'expense').length} 个
                          </div>
                          <span className="text-[9px] text-slate-400">支出分类</span>
                        </div>
                        <div className="p-2 rounded-xl border border-slate-100 bg-white text-center">
                          <div className="font-mono font-bold text-slate-700">
                            {settings.categories.filter(c => c.type === 'income').length} 个
                          </div>
                          <span className="text-[9px] text-slate-400">收入分类</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'stats' && (
                  <div className="space-y-3">
                    <p className="text-[11px] text-slate-500 leading-relaxed font-semibold">
                      图表正在读取当月真实的收支明细进行可视化汇总：
                    </p>
                    <div className="p-2.5 bg-slate-900 rounded-xl text-[10px] font-mono text-green-400 leading-relaxed overflow-x-auto">
                      {`const ChartConfig = {`}
                      <br />
                      {`  type: "PieChart",`}
                      <br />
                      {`  innerRadius: 60,`}
                      <br />
                      {`  outerRadius: 80,`}
                      <br />
                      {`  theme: "Professional",`}
                      <br />
                      {`  dataPoints: ${bills.length}`}
                      <br />
                      {`};`}
                    </div>
                  </div>
                )}
              </div>
            </section>
          </div>

          <footer className="p-4 border-t border-slate-100 bg-slate-50 text-[10px] text-slate-400 text-center font-semibold">
            本地存储 LocalStorage 双向绑定就绪
          </footer>
        </aside>

      </div>

    </div>
  );
}
