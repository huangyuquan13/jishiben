/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type TransactionType = 'expense' | 'income';

export interface Category {
  code: string;
  name: string;
  icon: string;
  type: TransactionType;
}

export interface Bill {
  id: string;
  type: TransactionType;
  amount: number;
  category: string;
  categoryName: string;
  categoryIcon: string;
  date: string; // YYYY-MM-DD
  note: string;
  createTime: number; // timestamp
}

export interface UserSettings {
  monthlyBudget: number;
  categories: Category[];
}
