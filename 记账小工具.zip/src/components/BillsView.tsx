/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { Calendar, Search, Filter, ArrowLeft, ArrowRight, X, Trash2 } from 'lucide-react';
import { Bill } from '../types';

interface BillsViewProps {
  bills: Bill[];
  onDeleteBill: (id: string) => Promise<void>;
}

export default function BillsView({ bills, onDeleteBill }: BillsViewProps) {
  const [selectedMonth, setSelectedMonth] = useState('2026-07');
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'expense' | 'income'>('all');
  const [selectedCategoryCode, setSelectedCategoryCode] = useState<string>('all');

  // Month options (last 6 months including July 2026)
  const monthOptions = [
    '2026-07', '2026-06', '2026-05', '2026-04', '2026-03', '2026-02'
  ];

  // Unique categories list in the bills for local filtering
  const availableCategories = useMemo(() => {
    const codes = new Map<string, string>();
    bills.forEach(b => {
      codes.set(b.category, b.categoryName);
    });
    return Array.from(codes.entries()).map(([code, name]) => ({ code, name }));
  }, [bills]);

  // Navigate months
  const handlePrevMonth = () => {
    const currentIndex = monthOptions.indexOf(selectedMonth);
    if (currentIndex < monthOptions.length - 1) {
      setSelectedMonth(monthOptions[currentIndex + 1]);
    }
  };

  const handleNextMonth = () => {
    const currentIndex = monthOptions.indexOf(selectedMonth);
    if (currentIndex > 0) {
      setSelectedMonth(monthOptions[currentIndex - 1]);
    }
  };

  // Filter bills
  const filteredBills = useMemo(() => {
    return bills.filter((bill) => {
      // 1. Month filter
      const matchesMonth = bill.date.startsWith(selectedMonth);
      if (!matchesMonth) return false;

      // 2. Type filter
      if (typeFilter !== 'all' && bill.type !== typeFilter) return false;

      // 3. Category filter
      if (selectedCategoryCode !== 'all' && bill.category !== selectedCategoryCode) return false;

      // 4. Search query
      if (searchQuery.trim() !== '') {
        const query = searchQuery.toLowerCase();
        const matchesNote = bill.note.toLowerCase().includes(query);
        const matchesCategory = bill.categoryName.toLowerCase().includes(query);
        const matchesAmount = bill.amount.toString().includes(query);
        if (!matchesNote && !matchesCategory && !matchesAmount) return false;
      }

      return true;
    });
  }, [bills, selectedMonth, typeFilter, selectedCategoryCode, searchQuery]);

  // Calculate monthly aggregates for filtered month
  const { totalIncome, totalExpense } = useMemo(() => {
    const monthBills = bills.filter((b) => b.date.startsWith(selectedMonth));
    let income = 0;
    let expense = 0;
    monthBills.forEach((b) => {
      if (b.type === 'income') {
        income += b.amount;
      } else {
        expense += b.amount;
      }
    });
    return {
      totalIncome: Number(income.toFixed(2)),
      totalExpense: Number(expense.toFixed(2)),
    };
  }, [bills, selectedMonth]);

  // Group filtered bills by date (YYYY-MM-DD)
  const groupedBillsByDate = useMemo(() => {
    const groups: Record<string, { date: string; dayTotalExpense: number; dayTotalIncome: number; items: Bill[] }> = {};
    
    // Sort items newest first
    const sorted = [...filteredBills].sort((a, b) => {
      // Sort by date first, then by timestamp
      if (a.date !== b.date) {
        return b.date.localeCompare(a.date);
      }
      return b.createTime - a.createTime;
    });

    sorted.forEach((bill) => {
      if (!groups[bill.date]) {
        groups[bill.date] = {
          date: bill.date,
          dayTotalExpense: 0,
          dayTotalIncome: 0,
          items: [],
        };
      }
      groups[bill.date].items.push(bill);
      if (bill.type === 'expense') {
        groups[bill.date].dayTotalExpense += bill.amount;
      } else {
        groups[bill.date].dayTotalIncome += bill.amount;
      }
    });

    return Object.values(groups).sort((a, b) => b.date.localeCompare(a.date));
  }, [filteredBills]);

  // Helper to format date header (e.g. "07/07 周三")
  const formatDayHeader = (dateStr: string) => {
    try {
      const parts = dateStr.split('-');
      const date = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
      const weekDays = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
      const weekDay = weekDays[date.getDay()];
      return `${parts[1]}/${parts[2]} ${weekDay}`;
    } catch (e) {
      return dateStr;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50/50 pb-24 font-sans">
      
      {/* Top sticky controls */}
      <header className="sticky top-0 z-30 bg-white shadow-xs border-b border-slate-100">
        
        {/* Month selector banner */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-50">
          <button
            id="prev_month_btn"
            onClick={handlePrevMonth}
            disabled={monthOptions.indexOf(selectedMonth) === monthOptions.length - 1}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-50 disabled:opacity-30 cursor-pointer"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>

          <div className="flex items-center space-x-1.5 text-xs font-bold text-slate-700">
            <Calendar className="h-4 w-4 text-emerald-500" />
            <select
              id="bills_month_select"
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="bg-transparent font-mono font-bold outline-hidden cursor-pointer"
            >
              {monthOptions.map((m) => {
                const [y, mm] = m.split('-');
                return (
                  <option key={m} value={m}>
                    {y}年{mm}月
                  </option>
                );
              })}
            </select>
          </div>

          <button
            id="next_month_btn"
            onClick={handleNextMonth}
            disabled={monthOptions.indexOf(selectedMonth) === 0}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-50 disabled:opacity-30 cursor-pointer"
          >
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>

        {/* Income / Expense summary bar */}
        <div className="grid grid-cols-2 divide-x divide-slate-100 bg-emerald-50/20 py-2.5 text-center text-xs">
          <div>
            <span className="text-[10px] text-slate-400 font-semibold block">当月总支出</span>
            <span className="font-mono text-sm font-bold text-rose-500">
              ¥{totalExpense.toFixed(2)}
            </span>
          </div>
          <div>
            <span className="text-[10px] text-slate-400 font-semibold block">当月总收入</span>
            <span className="font-mono text-sm font-bold text-emerald-600">
              ¥{totalIncome.toFixed(2)}
            </span>
          </div>
        </div>

        {/* Filtering & Search bar */}
        <div className="p-3 space-y-2">
          {/* Search box */}
          <div className="relative flex items-center rounded-xl bg-slate-50 border border-slate-100 px-3 py-1.5 focus-within:border-slate-300 focus-within:bg-white transition-all">
            <Search className="h-4 w-4 text-slate-400 mr-2 shrink-0" />
            <input
              type="text"
              id="bills_search_input"
              placeholder="搜索账单备注、分类或金额..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-transparent text-xs text-slate-700 placeholder-slate-400 outline-hidden"
            />
            {searchQuery && (
              <button
                id="clear_search_btn"
                onClick={() => setSearchQuery('')}
                className="text-slate-400 hover:text-slate-600 ml-1.5 shrink-0"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          {/* Quick Filter tabs */}
          <div className="flex items-center space-x-2.5 pt-0.5 overflow-x-auto scrollbar-none">
            {/* Type tabs */}
            <div className="flex rounded-lg bg-slate-100 p-0.5 text-[10px] font-bold">
              <button
                id="filter_type_all"
                onClick={() => setTypeFilter('all')}
                className={`px-3 py-1 rounded-md transition-all cursor-pointer ${
                  typeFilter === 'all' ? 'bg-white text-slate-800 shadow-xs' : 'text-slate-500'
                }`}
              >
                全部
              </button>
              <button
                id="filter_type_expense"
                onClick={() => setTypeFilter('expense')}
                className={`px-3 py-1 rounded-md transition-all cursor-pointer ${
                  typeFilter === 'expense' ? 'bg-white text-rose-500 shadow-xs' : 'text-slate-500'
                }`}
              >
                支出
              </button>
              <button
                id="filter_type_income"
                onClick={() => setTypeFilter('income')}
                className={`px-3 py-1 rounded-md transition-all cursor-pointer ${
                  typeFilter === 'income' ? 'bg-white text-emerald-600 shadow-xs' : 'text-slate-500'
                }`}
              >
                收入
              </button>
            </div>

            {/* Category dropdown */}
            <div className="flex items-center rounded-lg border border-slate-200 bg-white px-2 py-1 text-[10px] font-semibold text-slate-600">
              <Filter className="h-3 w-3 text-slate-400 mr-1 shrink-0" />
              <select
                id="filter_category_select"
                value={selectedCategoryCode}
                onChange={(e) => setSelectedCategoryCode(e.target.value)}
                className="bg-transparent outline-hidden cursor-pointer"
              >
                <option value="all">全部分类</option>
                {availableCategories.map((cat) => (
                  <option key={cat.code} value={cat.code}>
                    {cat.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </header>

      {/* Grouped Bills List */}
      <main className="mx-auto max-w-md px-4 pt-4">
        {groupedBillsByDate.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-slate-300 bg-white rounded-2xl border border-slate-100 p-6 shadow-xs">
            <span className="text-4xl mb-2">🔍</span>
            <span className="text-xs font-semibold text-slate-400">该月未筛选到账单记录</span>
            <span className="text-[10px] text-slate-300 mt-1">您可以试着切换分类、月份或清除搜索条件</span>
          </div>
        ) : (
          <div className="space-y-4">
            {groupedBillsByDate.map((group) => (
              <div key={group.date} className="rounded-2xl border border-slate-100 bg-white overflow-hidden shadow-xs">
                {/* Day Header Bar */}
                <div className="flex justify-between items-center bg-slate-50 px-4 py-2 text-[10px] font-bold text-slate-500 border-b border-slate-100/50">
                  <span className="font-sans">{formatDayHeader(group.date)}</span>
                  <div className="flex items-center space-x-2 font-mono">
                    {group.dayTotalIncome > 0 && (
                      <span className="text-emerald-600">
                        收: ¥{group.dayTotalIncome.toFixed(2)}
                      </span>
                    )}
                    {group.dayTotalExpense > 0 && (
                      <span className="text-rose-500">
                        支: ¥{group.dayTotalExpense.toFixed(2)}
                      </span>
                    )}
                  </div>
                </div>

                {/* Day transactions list */}
                <div className="divide-y divide-slate-50">
                  {group.items.map((bill) => (
                    <div key={bill.id} className="flex items-center justify-between px-4 py-3 group hover:bg-slate-50/30 transition-colors">
                      <div className="flex items-center space-x-3 overflow-hidden">
                        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-slate-50 text-lg border border-slate-100">
                          {bill.categoryIcon}
                        </span>
                        <div className="overflow-hidden">
                          <div className="flex items-center space-x-1.5">
                            <span className="text-xs font-bold text-slate-700 truncate">{bill.note}</span>
                            <span className="rounded-md bg-slate-100 px-1.5 py-0.5 text-[9px] font-semibold text-slate-400">
                              {bill.categoryName}
                            </span>
                          </div>
                          {/* Format timestamp to show actual clock time if available */}
                          <span className="font-mono text-[9px] text-slate-400 block mt-0.5">
                            {new Date(bill.createTime).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', hour12: false })}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center space-x-3 font-mono shrink-0">
                        <span className={`text-xs font-bold ${
                          bill.type === 'expense' ? 'text-rose-500' : 'text-emerald-500'
                        }`}>
                          {bill.type === 'expense' ? '-' : '+'}{bill.amount.toFixed(2)}
                        </span>
                        <button
                          id={`bills_delete_btn_${bill.id}`}
                          onClick={() => onDeleteBill(bill.id)}
                          className="rounded-lg p-1 text-slate-300 hover:text-rose-500 hover:bg-rose-50 opacity-100 sm:opacity-0 group-hover:opacity-100 transition-all cursor-pointer"
                          title="删除记录"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
