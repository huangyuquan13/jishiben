/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Plus, Trash2, TrendingUp, Calendar, FileText, ChevronRight, AlertCircle, X, Check } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { Bill, Category, UserSettings } from '../types';

interface HomeViewProps {
  bills: Bill[];
  settings: UserSettings;
  onAddBill: (billData: Omit<Bill, 'id' | 'createTime'>) => Promise<void>;
  onDeleteBill: (id: string) => Promise<void>;
  onNavigateToStats: () => void;
}

export default function HomeView({
  bills,
  settings,
  onAddBill,
  onDeleteBill,
  onNavigateToStats,
}: HomeViewProps) {
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  
  // Half-screen form state
  const [txType, setTxType] = useState<'expense' | 'income'>('expense');
  const [amount, setAmount] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [txDate, setTxDate] = useState<string>(() => {
    const today = new Date();
    const y = today.getFullYear();
    const m = String(today.getMonth() + 1).padStart(2, '0');
    const d = String(today.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  });
  const [txNote, setTxNote] = useState('');
  const [formError, setFormError] = useState('');

  // Calculate stats for current month (July 2026, or current actual month from mock data)
  // Let's use the actual dates in July 2026 as the active month since the current local time metadata says 2026-07-07
  const currentMonth = '2026-07';
  const julyBills = bills.filter((b) => b.date.startsWith(currentMonth));
  
  const totalExpense = julyBills
    .filter((b) => b.type === 'expense')
    .reduce((sum, b) => sum + b.amount, 0);

  const budget = settings.monthlyBudget;
  const budgetProgress = budget > 0 ? (totalExpense / budget) * 100 : 0;
  const remainingBudget = budget - totalExpense;

  // Filter categories by selected transaction type
  const filteredCategories = settings.categories.filter((c) => c.type === txType);

  // Set default category when type changes
  React.useEffect(() => {
    if (filteredCategories.length > 0) {
      setSelectedCategory(filteredCategories[0]);
    }
  }, [txType, settings.categories]);

  // Get recent 3 bills
  const recentBills = [...bills].slice(0, 3);

  // Fast note suggestions based on transaction type
  const expenseSuggestions = ['午餐', '晚餐', '买菜', '地铁', '打车', '日用品', '买衣服', '饮料水果'];
  const incomeSuggestions = ['工资', '奖金', '兼职收益', '转账红包', '二手出售', '投资分红'];
  const activeSuggestions = txType === 'expense' ? expenseSuggestions : incomeSuggestions;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setFormError('请输入大于 0 的有效金额');
      return;
    }

    if (!selectedCategory) {
      setFormError('请选择一个分类');
      return;
    }

    try {
      await onAddBill({
        type: txType,
        amount: parsedAmount,
        category: selectedCategory.code,
        categoryName: selectedCategory.name,
        categoryIcon: selectedCategory.icon,
        date: txDate,
        note: txNote.trim() || selectedCategory.name,
      });

      // Clear form & close
      setAmount('');
      setTxNote('');
      setIsPopupOpen(false);
    } catch (err) {
      setFormError('保存失败，请重试');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50/50 pb-24 font-sans">
      {/* Top Welcome Header */}
      <header className="bg-white px-5 pt-6 pb-4 border-b border-slate-100 shadow-xs">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-extrabold tracking-tight text-slate-800 font-sans">记账小工具</h1>
            <p className="text-[11px] text-slate-400 mt-0.5 font-medium">Simple & Elegant Bookkeeping</p>
          </div>
          <button
            id="navigate_to_stats_btn"
            onClick={onNavigateToStats}
            className="flex items-center space-x-1 rounded-full bg-slate-50 border border-slate-100 px-3 py-1 text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <TrendingUp className="h-3.5 w-3.5 text-emerald-500" />
            <span>支出统计</span>
            <ChevronRight className="h-3.5 w-3.5 text-slate-400" />
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="mx-auto max-w-md px-4 pt-4 space-y-4">
        
        {/* Monthly Budget Card */}
        <div className="relative overflow-hidden rounded-2xl border border-slate-100 bg-white p-5 shadow-xs transition-transform hover:scale-[1.01]">
          {/* Subtle design element */}
          <div className="absolute right-0 top-0 -mr-4 -mt-4 h-20 w-20 rounded-full bg-emerald-50/40 blur-xl" />
          
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[10px] font-bold text-slate-400 tracking-wider uppercase">2026年7月支出</span>
              <div className="mt-1 flex items-baseline space-x-1">
                <span className="font-mono text-3xl font-extrabold text-slate-800 tracking-tight">
                  ¥{totalExpense.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
                </span>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-bold text-slate-400 tracking-wider uppercase">本月预算</span>
              <div className="mt-1 font-mono text-sm font-semibold text-slate-600">
                ¥{budget.toLocaleString('zh-CN')}
              </div>
            </div>
          </div>

          {/* Budget progress bar */}
          <div className="mt-4">
            <div className="flex justify-between items-center text-[10px] text-slate-400 font-medium mb-1.5">
              <span>预算进度 {budgetProgress.toFixed(0)}%</span>
              <span className={remainingBudget < 0 ? 'text-rose-500 font-bold' : 'text-slate-500'}>
                {remainingBudget >= 0 ? `剩余 ¥${remainingBudget.toFixed(2)}` : `超支 ¥${Math.abs(remainingBudget).toFixed(2)}`}
              </span>
            </div>
            
            <div className="h-2.5 w-full rounded-full bg-slate-50 overflow-hidden border border-slate-100/50">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  budgetProgress >= 100 
                    ? 'bg-rose-500' 
                    : budgetProgress >= 80 
                    ? 'bg-amber-500' 
                    : 'bg-emerald-500'
                }`}
                style={{ width: `${Math.min(budgetProgress, 100)}%` }}
              />
            </div>
          </div>

          {budgetProgress >= 100 && (
            <div className="mt-3 flex items-center space-x-1.5 rounded-lg bg-rose-50 px-2.5 py-1.5 text-[11px] text-rose-600 font-medium border border-rose-100 animate-pulse">
              <AlertCircle className="h-3.5 w-3.5 shrink-0" />
              <span>本月支出已超出设定预算，建议合理规划消费！</span>
            </div>
          )}
        </div>

        {/* Floating Quick Entry Trigger */}
        <button
          id="open_quick_entry_btn"
          onClick={() => setIsPopupOpen(true)}
          className="flex w-full items-center justify-center space-x-2 rounded-2xl bg-slate-800 py-3.5 px-4 text-sm font-semibold text-white shadow-md hover:bg-slate-700 active:scale-95 transition-all"
        >
          <Plus className="h-4.5 w-4.5" />
          <span>记一笔账单</span>
        </button>

        {/* Recent 3 Bills Section */}
        <div className="rounded-2xl border border-slate-100 bg-white p-4 shadow-xs">
          <div className="mb-3.5 flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-600 tracking-wider">最近账单 (3 笔)</h3>
            <span className="text-[10px] text-slate-400">实时同步</span>
          </div>

          {recentBills.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-slate-300">
              <span className="text-3xl mb-1">📝</span>
              <span className="text-xs">暂无账单记录，快记一笔吧！</span>
            </div>
          ) : (
            <div className="divide-y divide-slate-50">
              {recentBills.map((bill) => (
                <div key={bill.id} className="flex items-center justify-between py-3.5 group">
                  <div className="flex items-center space-x-3 overflow-hidden">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-slate-50 text-lg border border-slate-100">
                      {bill.categoryIcon}
                    </span>
                    <div className="overflow-hidden">
                      <div className="flex items-center space-x-1.5">
                        <span className="text-xs font-bold text-slate-700 truncate">{bill.note}</span>
                        <span className="rounded-md bg-slate-100 px-1.5 py-0.5 text-[9px] font-semibold text-slate-400">
                          {bill.categoryName}
                        </span>
                      </div>
                      <span className="font-mono text-[9px] text-slate-400 block mt-0.5">
                        {bill.date}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3 font-mono shrink-0">
                    <span className={`text-xs font-bold ${
                      bill.type === 'expense' ? 'text-rose-500' : 'text-emerald-500'
                    }`}>
                      {bill.type === 'expense' ? '-' : '+'}{bill.amount.toFixed(2)}
                    </span>
                    <button
                      id={`delete_bill_btn_${bill.id}`}
                      onClick={() => onDeleteBill(bill.id)}
                      className="rounded-lg p-1 text-slate-300 hover:text-rose-500 hover:bg-rose-50 opacity-100 sm:opacity-0 group-hover:opacity-100 transition-all cursor-pointer"
                      title="删除记录"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Half Screen Popup Form (Bottom Drawer) */}
      <AnimatePresence>
        {isPopupOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              id="modal_backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsPopupOpen(false)}
              className="fixed inset-0 z-40 bg-black"
            />
            
            {/* Drawer Container */}
            <motion.div
              id="modal_drawer"
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 220 }}
              className="fixed inset-x-0 bottom-0 z-50 max-h-[90vh] overflow-y-auto rounded-t-3xl bg-white shadow-2xl border-t border-slate-100 pb-8 font-sans"
            >
              {/* Top notch */}
              <div className="mx-auto my-2.5 h-1 w-12 rounded-full bg-slate-200" />

              {/* Popup Header */}
              <div className="flex items-center justify-between px-5 py-2.5 border-b border-slate-50">
                <span className="text-sm font-bold text-slate-800">记一笔账单</span>
                <button
                  id="close_popup_btn"
                  onClick={() => setIsPopupOpen(false)}
                  className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-colors"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Form Content */}
              <form onSubmit={handleSubmit} className="p-5 space-y-4">
                {formError && (
                  <div className="flex items-center space-x-2 rounded-xl bg-rose-50 border border-rose-100 px-3.5 py-2.5 text-xs text-rose-600">
                    <AlertCircle className="h-4 w-4 shrink-0" />
                    <span>{formError}</span>
                  </div>
                )}

                {/* Tab select: Expense vs Income */}
                <div className="flex rounded-xl bg-slate-100 p-1">
                  <button
                    type="button"
                    id="form_type_expense"
                    onClick={() => setTxType('expense')}
                    className={`flex-1 py-2 text-center text-xs font-bold transition-all rounded-lg cursor-pointer ${
                      txType === 'expense'
                        ? 'bg-white text-rose-600 shadow-xs'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    支出
                  </button>
                  <button
                    type="button"
                    id="form_type_income"
                    onClick={() => setTxType('income')}
                    className={`flex-1 py-2 text-center text-xs font-bold transition-all rounded-lg cursor-pointer ${
                      txType === 'income'
                        ? 'bg-white text-emerald-600 shadow-xs'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    收入
                  </button>
                </div>

                {/* Amount input block */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">账单金额 (元)</label>
                  <div className="relative flex items-center rounded-2xl border border-slate-200 bg-slate-50 px-3.5 focus-within:border-slate-400 focus-within:bg-white transition-all">
                    <span className="font-sans text-xl font-bold text-slate-400 mr-1.5">¥</span>
                    <input
                      type="number"
                      id="form_amount_input"
                      step="0.01"
                      required
                      placeholder="0.00"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="w-full bg-transparent py-3.5 font-mono text-2xl font-bold text-slate-800 placeholder-slate-300 outline-hidden"
                    />
                  </div>
                </div>

                {/* Grid for category selection */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">选择分类</label>
                  <div className="grid grid-cols-4 gap-2">
                    {filteredCategories.map((cat) => {
                      const isSelected = selectedCategory?.code === cat.code;
                      return (
                        <button
                          key={cat.code}
                          type="button"
                          id={`form_cat_${cat.code}`}
                          onClick={() => setSelectedCategory(cat)}
                          className={`flex flex-col items-center justify-center p-2.5 rounded-xl border transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-emerald-50/50 border-emerald-500 text-emerald-600'
                              : 'bg-white border-slate-100 text-slate-600 hover:border-slate-200 hover:bg-slate-50/50'
                          }`}
                        >
                          <span className="text-xl mb-1">{cat.icon}</span>
                          <span className="text-[10px] font-bold truncate max-w-full">{cat.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Date Picker & Notes */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">日期</label>
                    <div className="flex items-center rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-700 focus-within:border-slate-400 focus-within:bg-white transition-all">
                      <Calendar className="h-3.5 w-3.5 text-slate-400 mr-1.5 shrink-0" />
                      <input
                        type="date"
                        id="form_date_input"
                        required
                        value={txDate}
                        onChange={(e) => setTxDate(e.target.value)}
                        className="w-full bg-transparent outline-hidden font-mono"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">备注</label>
                    <div className="flex items-center rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-700 focus-within:border-slate-400 focus-within:bg-white transition-all">
                      <FileText className="h-3.5 w-3.5 text-slate-400 mr-1.5 shrink-0" />
                      <input
                        type="text"
                        id="form_note_input"
                        placeholder="例如：午餐外卖"
                        value={txNote}
                        onChange={(e) => setTxNote(e.target.value)}
                        className="w-full bg-transparent outline-hidden"
                      />
                    </div>
                  </div>
                </div>

                {/* Suggestions buttons */}
                <div>
                  <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">常用备注推荐</span>
                  <div className="flex flex-wrap gap-1.5">
                    {activeSuggestions.map((suggestion) => (
                      <button
                        key={suggestion}
                        type="button"
                        id={`form_suggest_${suggestion}`}
                        onClick={() => setTxNote(suggestion)}
                        className="rounded-lg bg-slate-100 px-2.5 py-1 text-[10px] font-bold text-slate-600 hover:bg-slate-200 transition-colors cursor-pointer"
                      >
                        {suggestion}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Submit button */}
                <button
                  type="submit"
                  id="form_submit_btn"
                  className="flex w-full items-center justify-center space-x-1.5 rounded-xl bg-slate-800 py-3 text-xs font-bold text-white shadow-md hover:bg-slate-700 active:scale-95 transition-all cursor-pointer"
                >
                  <Check className="h-4 w-4" />
                  <span>保存账单</span>
                </button>
              </form>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
