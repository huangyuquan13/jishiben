/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ArrowLeft, Calendar, TrendingUp, DollarSign, PieChart as PieIcon, BarChart2 } from 'lucide-react';
import { Bill, Category } from '../types';
import { api } from '../mockData';
import { ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';

interface StatsViewProps {
  onBack: () => void;
  initialMonth?: string;
}

export default function StatsView({ onBack, initialMonth = '2026-07' }: StatsViewProps) {
  const [selectedMonth, setSelectedMonth] = useState<string>(initialMonth);
  const [activeTab, setActiveTab] = useState<'expense' | 'income'>('expense');
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<{
    totalExpense: number;
    totalIncome: number;
    budget: number;
    categoryExpenses: any[];
    categoryIncomes: any[];
  } | null>(null);
  const [dailyTrend, setDailyTrend] = useState<any[]>([]);

  // Month list for selection (last 6 months including July 2026)
  const monthOptions = [
    '2026-07', '2026-06', '2026-05', '2026-04', '2026-03', '2026-02'
  ];

  useEffect(() => {
    async function loadData() {
      setLoading(true);
      try {
        const statsData = await api.getMonthlyStats(selectedMonth);
        const trendData = await api.getDailyTrend(selectedMonth);
        setStats(statsData);
        setDailyTrend(trendData);
      } catch (e) {
        console.error('Error fetching stats data:', e);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [selectedMonth]);

  const currentCategoryStats = activeTab === 'expense' 
    ? stats?.categoryExpenses || [] 
    : stats?.categoryIncomes || [];

  const totalAmount = activeTab === 'expense'
    ? stats?.totalExpense || 0
    : stats?.totalIncome || 0;

  // Modern soft color palette for categories
  const COLORS = [
    '#4CAF50', '#FF9800', '#2196F3', '#E91E63', 
    '#9C27B0', '#00BCD4', '#FFEB3B', '#795548', 
    '#607D8B', '#FF5722', '#9E9E9E', '#3F51B5'
  ];

  // Filter daily trend to show only days with some transactions to keep the chart clean on mobile
  const activeTrendData = dailyTrend.filter(d => d.expense > 0 || d.income > 0);

  return (
    <div className="min-h-screen bg-slate-50/50 pb-12 font-sans">
      {/* Header */}
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-slate-100 bg-white px-4 py-3.5 shadow-xs">
        <div className="flex items-center space-x-3">
          <button 
            id="stats_back_btn"
            onClick={onBack}
            className="rounded-full p-1.5 text-slate-600 transition-colors hover:bg-slate-100"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <h1 className="text-lg font-semibold text-slate-800">
            {activeTab === 'expense' ? '支出统计' : '收入统计'}
          </h1>
        </div>

        {/* Month Selector */}
        <div className="relative flex items-center space-x-1.5 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs font-medium text-slate-700">
          <Calendar className="h-3.5 w-3.5 text-slate-500" />
          <select
            id="stats_month_select"
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="bg-transparent pr-1 font-mono font-medium outline-hidden cursor-pointer"
          >
            {monthOptions.map((m) => {
              const [y, mm] = m.split('-');
              return (
                <option key={m} value={m}>
                  {y}年{mm}月
                </option>
              );
            })}
          </select>
        </div>
      </header>

      {/* Main Container */}
      <main className="mx-auto max-w-md px-4 pt-4">
        {/* Type Toggle Tabs */}
        <div className="mb-4 flex rounded-xl bg-slate-100 p-1">
          <button
            id="stats_expense_tab"
            onClick={() => setActiveTab('expense')}
            className={`flex-1 py-2 text-center text-sm font-semibold transition-all rounded-lg ${
              activeTab === 'expense'
                ? 'bg-white text-emerald-600 shadow-xs'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            支出统计
          </button>
          <button
            id="stats_income_tab"
            onClick={() => setActiveTab('income')}
            className={`flex-1 py-2 text-center text-sm font-semibold transition-all rounded-lg ${
              activeTab === 'income'
                ? 'bg-white text-emerald-600 shadow-xs'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            收入统计
          </button>
        </div>

        {loading ? (
          <div className="flex h-64 flex-col items-center justify-center space-y-2 rounded-2xl bg-white p-6 shadow-xs border border-slate-100">
            <div className="h-8 w-8 animate-spin rounded-full border-3 border-emerald-500 border-t-transparent" />
            <p className="text-xs text-slate-400">正在计算统计数据...</p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Summary Card */}
            <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-xs">
              <div className="text-xs text-slate-400">
                {selectedMonth.split('-')[1]}月总{activeTab === 'expense' ? '支出' : '收入'}
              </div>
              <div className="mt-1 flex items-baseline space-x-1">
                <span className="font-mono text-3xl font-bold tracking-tight text-slate-800">
                  ¥{totalAmount.toLocaleString('zh-CN', { minimumFractionDigits: 2 })}
                </span>
              </div>
              
              {activeTab === 'expense' && stats && (
                <div className="mt-3 border-t border-slate-50 pt-3 flex items-center justify-between text-xs text-slate-500">
                  <span>预算进度</span>
                  <span className={`font-mono font-medium ${stats.totalExpense > stats.budget ? 'text-rose-500 font-bold' : 'text-slate-600'}`}>
                    {stats.budget > 0 ? ((stats.totalExpense / stats.budget) * 100).toFixed(0) : 0}% 
                    ({stats.totalExpense > stats.budget ? '超支' : '未超支'})
                  </span>
                </div>
              )}
            </div>

            {/* Pie Chart Card */}
            <div className="rounded-2xl border border-slate-100 bg-white p-4 shadow-xs">
              <div className="mb-3 flex items-center space-x-1.5 text-xs font-semibold text-slate-600">
                <PieIcon className="h-4 w-4 text-emerald-500" />
                <span>分类占比分析</span>
              </div>

              {currentCategoryStats.length === 0 ? (
                <div className="flex h-48 flex-col items-center justify-center text-slate-300">
                  <span className="text-4xl mb-1">📊</span>
                  <span className="text-xs">该月暂无账单数据</span>
                </div>
              ) : (
                <div className="relative flex flex-col items-center justify-center">
                  <div className="h-56 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={currentCategoryStats}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={2}
                          dataKey="amount"
                        >
                          {currentCategoryStats.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip 
                          formatter={(value: any) => [`¥${value}`, '金额']}
                          contentStyle={{ borderRadius: '12px', fontSize: '12px', border: 'none', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  
                  {/* Center Text inside Pie */}
                  <div className="absolute top-[100px] text-center pointer-events-none">
                    <div className="text-[10px] font-medium text-slate-400">最多分类</div>
                    <div className="text-sm font-bold text-slate-700">
                      {currentCategoryStats[0]?.name || ''}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Daily Trend Chart Card */}
            <div className="rounded-2xl border border-slate-100 bg-white p-4 shadow-xs">
              <div className="mb-3 flex items-center space-x-1.5 text-xs font-semibold text-slate-600">
                <BarChart2 className="h-4 w-4 text-emerald-500" />
                <span>每日交易分布</span>
              </div>

              {activeTrendData.length === 0 ? (
                <div className="flex h-40 flex-col items-center justify-center text-slate-300">
                  <span className="text-4xl mb-1">📈</span>
                  <span className="text-xs">暂无每日走势</span>
                </div>
              ) : (
                <div className="h-48 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={activeTrendData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                      <XAxis dataKey="day" tick={{ fontSize: 10, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 10, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                      <Tooltip
                        formatter={(value: any) => [`¥${value}`, activeTab === 'expense' ? '支出' : '收入']}
                        contentStyle={{ borderRadius: '12px', fontSize: '12px', border: 'none', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' }}
                      />
                      <Bar 
                        dataKey={activeTab === 'expense' ? 'expense' : 'income'} 
                        fill={activeTab === 'expense' ? '#f43f5e' : '#10b981'} 
                        radius={[4, 4, 0, 0]} 
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>

            {/* Category Leaderboard */}
            <div className="rounded-2xl border border-slate-100 bg-white p-4 shadow-xs">
              <div className="mb-3 text-xs font-semibold text-slate-600">分类排行明细</div>
              
              {currentCategoryStats.length === 0 ? (
                <div className="py-6 text-center text-xs text-slate-300">暂无排行数据</div>
              ) : (
                <div className="space-y-3.5">
                  {currentCategoryStats.map((item, index) => {
                    const color = COLORS[index % COLORS.length];
                    return (
                      <div key={item.code} className="group">
                        <div className="flex items-center justify-between text-xs mb-1.5">
                          <div className="flex items-center space-x-2.5">
                            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-slate-50 text-sm">
                              {item.icon}
                            </span>
                            <div>
                              <span className="font-semibold text-slate-700">{item.name}</span>
                              <span className="ml-2 font-mono text-[10px] text-slate-400">
                                {item.percentage}%
                              </span>
                            </div>
                          </div>
                          <span className="font-mono font-semibold text-slate-700">
                            ¥{item.amount.toFixed(2)}
                          </span>
                        </div>
                        {/* Custom Progress Bar */}
                        <div className="h-1.5 w-full rounded-full bg-slate-50 overflow-hidden">
                          <div 
                            className="h-full rounded-full transition-all duration-500" 
                            style={{ 
                              width: `${item.percentage}%`,
                              backgroundColor: color 
                            }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
