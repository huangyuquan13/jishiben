/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Home, Receipt, User } from 'lucide-react';

interface TabBarProps {
  activeTab: 'home' | 'bills' | 'my' | 'stats';
  onChangeTab: (tab: 'home' | 'bills' | 'my') => void;
}

export default function TabBar({ activeTab, onChangeTab }: TabBarProps) {
  // If activeTab is 'stats', we don't render the bottom TabBar to mimic a native app's subview/subpage
  if (activeTab === 'stats') return null;

  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-slate-100 bg-white/95 backdrop-blur-md py-2 shadow-lg max-w-md mx-auto">
      <div className="flex items-center justify-around">
        {/* Tab 1: 首页 */}
        <button
          id="tab_home_btn"
          onClick={() => onChangeTab('home')}
          className={`flex flex-col items-center space-y-1 py-1.5 px-5 rounded-xl transition-all cursor-pointer ${
            activeTab === 'home'
              ? 'text-emerald-500 font-bold scale-105'
              : 'text-slate-400 hover:text-slate-600 font-medium'
          }`}
        >
          <Home className="h-5 w-5" />
          <span className="text-[10px] tracking-wider">首页</span>
        </button>

        {/* Tab 2: 账单 */}
        <button
          id="tab_bills_btn"
          onClick={() => onChangeTab('bills')}
          className={`flex flex-col items-center space-y-1 py-1.5 px-5 rounded-xl transition-all cursor-pointer ${
            activeTab === 'bills'
              ? 'text-emerald-500 font-bold scale-105'
              : 'text-slate-400 hover:text-slate-600 font-medium'
          }`}
        >
          <Receipt className="h-5 w-5" />
          <span className="text-[10px] tracking-wider">账单</span>
        </button>

        {/* Tab 3: 我的 */}
        <button
          id="tab_my_btn"
          onClick={() => onChangeTab('my')}
          className={`flex flex-col items-center space-y-1 py-1.5 px-5 rounded-xl transition-all cursor-pointer ${
            activeTab === 'my'
              ? 'text-emerald-500 font-bold scale-105'
              : 'text-slate-400 hover:text-slate-600 font-medium'
          }`}
        >
          <User className="h-5 w-5" />
          <span className="text-[10px] tracking-wider">我的</span>
        </button>
      </div>
    </nav>
  );
}
