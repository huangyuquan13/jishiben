/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  BarChart3, 
  Settings, 
  Layers, 
  Info, 
  ChevronRight, 
  DollarSign, 
  User, 
  Github, 
  Plus, 
  X, 
  Check, 
  Trash2, 
  AlertCircle 
} from 'lucide-react';
import { Category, UserSettings } from '../types';
import { AnimatePresence, motion } from 'motion/react';

interface MyViewProps {
  settings: UserSettings;
  onUpdateSettings: (settings: UserSettings) => Promise<void>;
  onNavigateToStats: () => void;
  userEmail?: string;
}

export default function MyView({ 
  settings, 
  onUpdateSettings, 
  onNavigateToStats,
  userEmail = 'hyq422906@gmail.com'
}: MyViewProps) {
  // Modal toggle states
  const [activeModal, setActiveModal] = useState<'budget' | 'category' | 'about' | null>(null);

  // Budget state
  const [budgetInput, setBudgetInput] = useState<string>(settings.monthlyBudget.toString());
  const [budgetError, setBudgetError] = useState('');

  // Category management state
  const [catType, setCatType] = useState<'expense' | 'income'>('expense');
  const [catName, setCatName] = useState('');
  const [catIcon, setCatIcon] = useState('📦');
  const [catError, setCatError] = useState('');

  // Predefined Emojis for custom categories
  const emojiOptions = [
    '🍔', '🍟', '🍕', '☕', '🍺', '🚗', '✈️', '🎮', '🍿', '🎬', 
    '🏠', '👔', '👠', '📱', '💻', '💊', '📚', '🏋️', '🐶', '🎁', 
    '💰', '📈', '🪙', '💼', '📦'
  ];

  const handleSaveBudget = async (e: React.FormEvent) => {
    e.preventDefault();
    setBudgetError('');
    const parsedBudget = parseFloat(budgetInput);
    if (isNaN(parsedBudget) || parsedBudget < 0) {
      setBudgetError('请输入大于等于 0 的有效预算金额');
      return;
    }

    try {
      await onUpdateSettings({
        ...settings,
        monthlyBudget: parsedBudget,
      });
      setActiveModal(null);
    } catch (err) {
      setBudgetError('预算更新失败，请重试');
    }
  };

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    setCatError('');

    const trimmedName = catName.trim();
    if (!trimmedName) {
      setCatError('请输入分类名称');
      return;
    }

    // Check if name or code already exists
    const code = 'custom_' + Date.now();
    const isDuplicate = settings.categories.some(
      (c) => c.name.toLowerCase() === trimmedName.toLowerCase() && c.type === catType
    );

    if (isDuplicate) {
      setCatError('该分类名称已存在');
      return;
    }

    const newCategory: Category = {
      code,
      name: trimmedName,
      icon: catIcon,
      type: catType,
    };

    try {
      const updatedCategories = [...settings.categories, newCategory];
      await onUpdateSettings({
        ...settings,
        categories: updatedCategories,
      });
      setCatName('');
      setCatIcon('📦');
    } catch (err) {
      setCatError('添加分类失败，请重试');
    }
  };

  const handleDeleteCategory = async (code: string) => {
    // Prevent deleting categories that are standard
    // Find category
    const cat = settings.categories.find(c => c.code === code);
    if (!cat) return;

    try {
      const updatedCategories = settings.categories.filter((c) => c.code !== code);
      await onUpdateSettings({
        ...settings,
        categories: updatedCategories,
      });
    } catch (err) {
      console.error('Failed to delete category:', err);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50/50 pb-24 font-sans">
      
      {/* Top Profile Header */}
      <header className="relative overflow-hidden bg-slate-900 px-5 pt-8 pb-10 text-white shadow-md">
        {/* Subtle decorative mesh background */}
        <div className="absolute right-0 top-0 -mr-6 -mt-6 h-32 w-32 rounded-full bg-emerald-500/10 blur-2xl" />
        <div className="absolute left-0 bottom-0 -ml-6 -mb-6 h-24 w-24 rounded-full bg-teal-500/10 blur-2xl" />

        <div className="flex items-center space-x-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-500 text-white shadow-inner font-extrabold text-lg">
            {userEmail.charAt(0).toUpperCase()}
          </div>
          <div>
            <h2 className="text-base font-bold tracking-tight">前端开发者</h2>
            <p className="text-[10px] text-slate-400 font-mono mt-0.5">{userEmail}</p>
          </div>
        </div>

        {/* Dynamic Multi-column Stat Grid from the design doc ("数据统计卡片: 收藏/菜谱/获赞/粉丝 (4个数字)") */}
        <div className="mt-6 grid grid-cols-4 gap-2 rounded-2xl bg-white/5 p-4 text-center border border-white/5 shadow-inner">
          <div>
            <div className="font-mono text-base font-extrabold text-white">4</div>
            <div className="text-[9px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">收藏</div>
          </div>
          <div>
            <div className="font-mono text-base font-extrabold text-white">0</div>
            <div className="text-[9px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">菜谱</div>
          </div>
          <div>
            <div className="font-mono text-base font-extrabold text-white">856</div>
            <div className="text-[9px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">获赞</div>
          </div>
          <div>
            <div className="font-mono text-base font-extrabold text-white">128</div>
            <div className="text-[9px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">粉丝</div>
          </div>
        </div>
      </header>

      {/* Profile menu list container */}
      <main className="mx-auto max-w-md px-4 -mt-5 space-y-4 relative z-10">
        
        <div className="rounded-2xl border border-slate-100 bg-white p-2.5 shadow-xs">
          
          {/* Menu item: 📊 支出统计 */}
          <button
            id="menu_stats_btn"
            onClick={onNavigateToStats}
            className="flex w-full items-center justify-between rounded-xl px-4 py-3.5 text-left text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <div className="flex items-center space-x-3 text-xs font-bold">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-50 text-emerald-500">
                <BarChart3 className="h-4.5 w-4.5" />
              </span>
              <span>📊 支出统计</span>
            </div>
            <ChevronRight className="h-4 w-4 text-slate-400" />
          </button>

          {/* Menu item: ⚙️ 预算设置 */}
          <button
            id="menu_budget_btn"
            onClick={() => {
              setBudgetInput(settings.monthlyBudget.toString());
              setActiveModal('budget');
            }}
            className="flex w-full items-center justify-between rounded-xl px-4 py-3.5 text-left text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <div className="flex items-center space-x-3 text-xs font-bold">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-50 text-emerald-500">
                <Settings className="h-4.5 w-4.5" />
              </span>
              <span>⚙️ 预算设置</span>
            </div>
            <div className="flex items-center space-x-1">
              <span className="font-mono text-xs text-slate-400">¥{settings.monthlyBudget}</span>
              <ChevronRight className="h-4 w-4 text-slate-400" />
            </div>
          </button>

          {/* Menu item: 📋 分类管理 */}
          <button
            id="menu_category_btn"
            onClick={() => setActiveModal('category')}
            className="flex w-full items-center justify-between rounded-xl px-4 py-3.5 text-left text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <div className="flex items-center space-x-3 text-xs font-bold">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-50 text-emerald-500">
                <Layers className="h-4.5 w-4.5" />
              </span>
              <span>📋 分类管理</span>
            </div>
            <div className="flex items-center space-x-1">
              <span className="text-[10px] text-slate-400 font-bold bg-slate-100 px-2 py-0.5 rounded-full">
                {settings.categories.length} 个
              </span>
              <ChevronRight className="h-4 w-4 text-slate-400" />
            </div>
          </button>

          {/* Menu item: ℹ️ 关于 */}
          <button
            id="menu_about_btn"
            onClick={() => setActiveModal('about')}
            className="flex w-full items-center justify-between rounded-xl px-4 py-3.5 text-left text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <div className="flex items-center space-x-3 text-xs font-bold">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-50 text-emerald-500">
                <Info className="h-4.5 w-4.5" />
              </span>
              <span>ℹ️ 关于小程序</span>
            </div>
            <ChevronRight className="h-4 w-4 text-slate-400" />
          </button>
        </div>
      </main>

      {/* Modals & Dialogs with Animations */}
      <AnimatePresence>
        {activeModal && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveModal(null)}
              className="fixed inset-0 z-40 bg-black"
            />

            {/* Modal Container */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              transition={{ type: 'spring', duration: 0.4 }}
              className="fixed inset-x-4 top-[15vh] z-50 mx-auto max-w-sm rounded-2xl bg-white p-5 shadow-2xl border border-slate-100"
            >
              {/* Modal header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-50 mb-4">
                <h3 className="text-sm font-bold text-slate-800">
                  {activeModal === 'budget' && '⚙️ 月度预算设置'}
                  {activeModal === 'category' && '📋 分类项目管理'}
                  {activeModal === 'about' && 'ℹ️ 关于记账小工具'}
                </h3>
                <button
                  onClick={() => setActiveModal(null)}
                  className="rounded-full p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-colors cursor-pointer"
                >
                  <X className="h-4.5 w-4.5" />
                </button>
              </div>

              {/* BUDGET MODAL */}
              {activeModal === 'budget' && (
                <form onSubmit={handleSaveBudget} className="space-y-4">
                  {budgetError && (
                    <div className="flex items-center space-x-2 rounded-lg bg-rose-50 px-2.5 py-1.5 text-[11px] text-rose-600">
                      <AlertCircle className="h-3.5 w-3.5 shrink-0" />
                      <span>{budgetError}</span>
                    </div>
                  )}
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">每月预算金额 (元)</label>
                    <div className="relative flex items-center rounded-xl border border-slate-200 bg-slate-50 px-3 py-1.5 focus-within:border-slate-400 focus-within:bg-white transition-all">
                      <span className="font-sans text-sm font-semibold text-slate-400 mr-1.5">¥</span>
                      <input
                        type="number"
                        id="budget_input_field"
                        required
                        value={budgetInput}
                        onChange={(e) => setBudgetInput(e.target.value)}
                        className="w-full bg-transparent py-1 font-mono text-lg font-bold text-slate-800 outline-hidden"
                      />
                    </div>
                    <span className="block text-[10px] text-slate-400 mt-1.5 leading-relaxed">
                      修改每月预算后，首页的进度条和统计分析将同步更新。
                    </span>
                  </div>

                  <button
                    type="submit"
                    id="save_budget_btn"
                    className="flex w-full items-center justify-center rounded-xl bg-slate-800 py-2.5 text-xs font-bold text-white shadow-md hover:bg-slate-700 transition-colors cursor-pointer"
                  >
                    保存设置
                  </button>
                </form>
              )}

              {/* CATEGORY MODAL */}
              {activeModal === 'category' && (
                <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
                  
                  {/* List of current categories with deletion */}
                  <div>
                    <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">当前分类列表</span>
                    <div className="space-y-1.5 max-h-[22vh] overflow-y-auto rounded-xl border border-slate-100 p-2 bg-slate-50/50">
                      {settings.categories.map((cat) => (
                        <div key={cat.code} className="flex items-center justify-between rounded-lg bg-white px-2.5 py-1.5 shadow-2xs border border-slate-100/50">
                          <div className="flex items-center space-x-2 text-xs">
                            <span className="text-base">{cat.icon}</span>
                            <span className="font-semibold text-slate-700">{cat.name}</span>
                            <span className={`text-[8px] font-bold px-1.5 py-0.2 rounded-md ${
                              cat.type === 'expense' ? 'bg-rose-50 text-rose-500' : 'bg-emerald-50 text-emerald-500'
                            }`}>
                              {cat.type === 'expense' ? '支出' : '收入'}
                            </span>
                          </div>
                          {/* Only allow deleting custom ones to keep defaults safe */}
                          {cat.code.startsWith('custom_') && (
                            <button
                              type="button"
                              id={`delete_cat_btn_${cat.code}`}
                              onClick={() => handleDeleteCategory(cat.code)}
                              className="text-slate-300 hover:text-rose-500 p-0.5 rounded-md hover:bg-rose-50 transition-colors cursor-pointer"
                              title="删除分类"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Add category form */}
                  <form onSubmit={handleAddCategory} className="border-t border-slate-50 pt-3 space-y-3">
                    <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">添加自定义分类</span>
                    
                    {catError && (
                      <div className="flex items-center space-x-1.5 rounded-lg bg-rose-50 px-2.5 py-1.5 text-[10px] text-rose-600">
                        <AlertCircle className="h-3.5 w-3.5 shrink-0" />
                        <span>{catError}</span>
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-2">
                      {/* Type tab */}
                      <div className="flex rounded-lg bg-slate-100 p-0.5 text-[10px] font-bold">
                        <button
                          type="button"
                          id="cat_type_expense"
                          onClick={() => setCatType('expense')}
                          className={`flex-1 py-1 rounded-md transition-all cursor-pointer ${
                            catType === 'expense' ? 'bg-white text-rose-500 shadow-3xs' : 'text-slate-500'
                          }`}
                        >
                          支出
                        </button>
                        <button
                          type="button"
                          id="cat_type_income"
                          onClick={() => setCatType('income')}
                          className={`flex-1 py-1 rounded-md transition-all cursor-pointer ${
                            catType === 'income' ? 'bg-white text-emerald-600 shadow-3xs' : 'text-slate-500'
                          }`}
                        >
                          收入
                        </button>
                      </div>

                      {/* Icon selected */}
                      <div className="flex items-center justify-between rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs">
                        <span className="text-slate-400 font-bold text-[9px] uppercase">当前图标:</span>
                        <span className="text-lg">{catIcon}</span>
                      </div>
                    </div>

                    {/* Name input */}
                    <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-1.5 focus-within:border-slate-400 focus-within:bg-white transition-all">
                      <input
                        type="text"
                        id="cat_name_input"
                        placeholder="输入分类名称（如：零食、宠物）"
                        required
                        value={catName}
                        onChange={(e) => setCatName(e.target.value)}
                        className="w-full bg-transparent text-xs text-slate-700 outline-hidden font-semibold"
                      />
                    </div>

                    {/* Emoji choices */}
                    <div>
                      <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">选择分类图标</span>
                      <div className="flex flex-wrap gap-1.5 max-h-[10vh] overflow-y-auto p-1.5 border border-slate-100 rounded-lg">
                        {emojiOptions.map((emoji) => (
                          <button
                            key={emoji}
                            type="button"
                            id={`emoji_btn_${emoji}`}
                            onClick={() => setCatIcon(emoji)}
                            className={`text-base p-1 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer ${
                              catIcon === emoji ? 'bg-emerald-50 border border-emerald-300 scale-110' : ''
                            }`}
                          >
                            {emoji}
                          </button>
                        ))}
                      </div>
                    </div>

                    <button
                      type="submit"
                      id="save_category_btn"
                      className="flex w-full items-center justify-center space-x-1 rounded-xl bg-slate-800 py-2 text-xs font-bold text-white shadow-md hover:bg-slate-700 transition-colors cursor-pointer"
                    >
                      <Plus className="h-3.5 w-3.5" />
                      <span>创建此分类</span>
                    </button>
                  </form>
                </div>
              )}

              {/* ABOUT MODAL */}
              {activeModal === 'about' && (
                <div className="space-y-4 text-center">
                  <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-500 text-white shadow-md text-2xl font-bold">
                    💰
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-800">记账小工具</h4>
                    <span className="text-[10px] text-slate-400 block font-mono mt-0.5">Version 1.0.0 (UniUI React Mock)</span>
                  </div>

                  <p className="text-left text-[11px] text-slate-500 leading-relaxed bg-slate-50/50 border border-slate-100 p-3 rounded-xl">
                    本小程序是结合了 <strong>uni-app + uni-ui</strong> 功能设计文档开发的记账本。支持本地数据持久化储存（LocalStorage），内嵌支出与收入饼图、折线分布图、每日汇总分组、自定义收支分类增删等强大功能。
                  </p>

                  <div className="border-t border-slate-50 pt-3 flex items-center justify-center space-x-4 text-xs text-slate-400">
                    <div className="flex items-center space-x-1">
                      <User className="h-3.5 w-3.5 text-emerald-500" />
                      <span>练手示范项目</span>
                    </div>
                    <span>•</span>
                    <div className="flex items-center space-x-1">
                      <Github className="h-3.5 w-3.5 text-slate-700" />
                      <span className="font-mono text-[10px]">React18 + Tailwind</span>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
