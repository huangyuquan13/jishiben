/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Bill, Category, UserSettings } from './types';

export const DEFAULT_CATEGORIES: Category[] = [
  // Expense (支出)
  { code: 'food', name: '餐饮', icon: '🍜', type: 'expense' },
  { code: 'shopping', name: '购物', icon: '🛒', type: 'expense' },
  { code: 'transport', name: '交通', icon: '🚌', type: 'expense' },
  { code: 'entertainment', name: '娱乐', icon: '🎮', type: 'expense' },
  { code: 'housing', name: '住房', icon: '🏠', type: 'expense' },
  { code: 'medical', name: '医疗', icon: '🏥', type: 'expense' },
  { code: 'education', name: '教育', icon: '🎓', type: 'expense' },
  { code: 'other_expense', name: '其他支出', icon: '📦', type: 'expense' },
  // Income (收入)
  { code: 'salary', name: '工资', icon: '💰', type: 'income' },
  { code: 'part_time', name: '兼职', icon: '💼', type: 'income' },
  { code: 'investment', name: '理财', icon: '📈', type: 'income' },
  { code: 'gift', name: '礼金', icon: '🎁', type: 'income' },
  { code: 'other_income', name: '其他收入', icon: '🪙', type: 'income' },
];

const INITIAL_BILLS: Bill[] = [
  {
    id: 'b1',
    type: 'expense',
    amount: 35.00,
    category: 'food',
    categoryName: '餐饮',
    categoryIcon: '🍜',
    date: '2026-07-07',
    note: '午餐麻辣烫外卖',
    createTime: new Date('2026-07-07T12:30:00').getTime(),
  },
  {
    id: 'b2',
    type: 'expense',
    amount: 8.00,
    category: 'transport',
    categoryName: '交通',
    categoryIcon: '🚌',
    date: '2026-07-07',
    note: '地铁出行',
    createTime: new Date('2026-07-07T08:45:00').getTime(),
  },
  {
    id: 'b3',
    type: 'expense',
    amount: 156.00,
    category: 'shopping',
    categoryName: '购物',
    categoryIcon: '🛒',
    date: '2026-07-06',
    note: '优衣库夏装短袖',
    createTime: new Date('2026-07-06T15:20:00').getTime(),
  },
  {
    id: 'b4',
    type: 'income',
    amount: 8500.00,
    category: 'salary',
    categoryName: '工资',
    categoryIcon: '💰',
    date: '2026-07-05',
    note: '6月份基本工资发放',
    createTime: new Date('2026-07-05T10:00:00').getTime(),
  },
  {
    id: 'b5',
    type: 'expense',
    amount: 120.00,
    category: 'entertainment',
    categoryName: '娱乐',
    categoryIcon: '🎮',
    date: '2026-07-04',
    note: 'Steam夏季大促买游戏',
    createTime: new Date('2026-07-04T21:10:00').getTime(),
  },
  {
    id: 'b6',
    type: 'expense',
    amount: 45.00,
    category: 'food',
    categoryName: '餐饮',
    categoryIcon: '🍜',
    date: '2026-07-03',
    note: '晚上和同事聚餐AA',
    createTime: new Date('2026-07-03T19:40:00').getTime(),
  },
  {
    id: 'b7',
    type: 'expense',
    amount: 15.00,
    category: 'transport',
    categoryName: '交通',
    categoryIcon: '🚌',
    date: '2026-07-02',
    note: '打车回家',
    createTime: new Date('2026-07-02T22:15:00').getTime(),
  },
  {
    id: 'b8',
    type: 'expense',
    amount: 2200.00,
    category: 'housing',
    categoryName: '住房',
    categoryIcon: '🏠',
    date: '2026-07-01',
    note: '7月份房租扣款',
    createTime: new Date('2026-07-01T09:00:00').getTime(),
  },
  // June bills for filter testing
  {
    id: 'b9',
    type: 'expense',
    amount: 65.00,
    category: 'food',
    categoryName: '餐饮',
    categoryIcon: '🍜',
    date: '2026-06-28',
    note: '海底捞火锅',
    createTime: new Date('2026-06-28T18:30:00').getTime(),
  },
  {
    id: 'b10',
    type: 'expense',
    amount: 49.00,
    category: 'shopping',
    categoryName: '购物',
    categoryIcon: '🛒',
    date: '2026-06-25',
    note: '生活日用品购买',
    createTime: new Date('2026-06-25T11:00:00').getTime(),
  },
  {
    id: 'b11',
    type: 'income',
    amount: 8500.00,
    category: 'salary',
    categoryName: '工资',
    categoryIcon: '💰',
    date: '2026-06-05',
    note: '5月份基本工资发放',
    createTime: new Date('2026-06-05T10:00:00').getTime(),
  },
  {
    id: 'b12',
    type: 'expense',
    amount: 300.00,
    category: 'education',
    categoryName: '教育',
    categoryIcon: '🎓',
    date: '2026-06-15',
    note: '网课学习教材',
    createTime: new Date('2026-06-15T14:00:00').getTime(),
  },
];

const LOCAL_STORAGE_BILLS_KEY = 'jizhang_bills';
const LOCAL_STORAGE_SETTINGS_KEY = 'jizhang_settings';

export function loadBills(): Bill[] {
  try {
    const data = localStorage.getItem(LOCAL_STORAGE_BILLS_KEY);
    if (data) {
      return JSON.parse(data);
    }
  } catch (e) {
    console.error('Error loading bills from localStorage:', e);
  }
  // Store initial ones if nothing exists
  saveBills(INITIAL_BILLS);
  return INITIAL_BILLS;
}

export function saveBills(bills: Bill[]): void {
  try {
    localStorage.setItem(LOCAL_STORAGE_BILLS_KEY, JSON.stringify(bills));
  } catch (e) {
    console.error('Error saving bills to localStorage:', e);
  }
}

export function loadSettings(): UserSettings {
  try {
    const data = localStorage.getItem(LOCAL_STORAGE_SETTINGS_KEY);
    if (data) {
      return JSON.parse(data);
    }
  } catch (e) {
    console.error('Error loading settings from localStorage:', e);
  }
  const defaultSettings: UserSettings = {
    monthlyBudget: 5000,
    categories: DEFAULT_CATEGORIES,
  };
  saveSettings(defaultSettings);
  return defaultSettings;
}

export function saveSettings(settings: UserSettings): void {
  try {
    localStorage.setItem(LOCAL_STORAGE_SETTINGS_KEY, JSON.stringify(settings));
  } catch (e) {
    console.error('Error saving settings to localStorage:', e);
  }
}

// Simulated Promise + setTimeout API layer as requested in the design doc
export const api = {
  // Get bills filtered by month (format: YYYY-MM)
  getBills(month: string): Promise<Bill[]> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const bills = loadBills();
        resolve(bills.filter((b) => b.date.startsWith(month)));
      }, 300);
    });
  },

  // Add a new bill
  addBill(billData: Omit<Bill, 'id' | 'createTime'>): Promise<Bill> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const bills = loadBills();
        const newBill: Bill = {
          ...billData,
          id: 'b_' + Date.now(),
          createTime: Date.now(),
        };
        bills.unshift(newBill); // Insert at the front
        saveBills(bills);
        resolve(newBill);
      }, 200);
    });
  },

  // Delete a bill
  deleteBill(id: string): Promise<boolean> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const bills = loadBills();
        const filtered = bills.filter((b) => b.id !== id);
        saveBills(filtered);
        resolve(true);
      }, 150);
    });
  },

  // Get user settings (budget, categories)
  getSettings(): Promise<UserSettings> {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(loadSettings());
      }, 150);
    });
  },

  // Update user settings
  updateSettings(settings: UserSettings): Promise<UserSettings> {
    return new Promise((resolve) => {
      setTimeout(() => {
        saveSettings(settings);
        resolve(settings);
      }, 200);
    });
  },

  // Get stats for a month: total income, total expense, and category breakdown
  getMonthlyStats(month: string): Promise<{
    totalExpense: number;
    totalIncome: number;
    budget: number;
    categoryExpenses: { name: string; amount: number; percentage: number; icon: string; code: string }[];
    categoryIncomes: { name: string; amount: number; percentage: number; icon: string; code: string }[];
  }> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const bills = loadBills().filter((b) => b.date.startsWith(month));
        const settings = loadSettings();

        let totalExpense = 0;
        let totalIncome = 0;

        const expenseMap: Record<string, { amount: number; name: string; icon: string }> = {};
        const incomeMap: Record<string, { amount: number; name: string; icon: string }> = {};

        bills.forEach((b) => {
          if (b.type === 'expense') {
            totalExpense += b.amount;
            if (!expenseMap[b.category]) {
              expenseMap[b.category] = { amount: 0, name: b.categoryName, icon: b.categoryIcon };
            }
            expenseMap[b.category].amount += b.amount;
          } else {
            totalIncome += b.amount;
            if (!incomeMap[b.category]) {
              incomeMap[b.category] = { amount: 0, name: b.categoryName, icon: b.categoryIcon };
            }
            incomeMap[b.category].amount += b.amount;
          }
        });

        const categoryExpenses = Object.entries(expenseMap).map(([code, data]) => ({
          code,
          name: data.name,
          icon: data.icon,
          amount: Number(data.amount.toFixed(2)),
          percentage: totalExpense > 0 ? Number(((data.amount / totalExpense) * 100).toFixed(1)) : 0,
        })).sort((a, b) => b.amount - a.amount);

        const categoryIncomes = Object.entries(incomeMap).map(([code, data]) => ({
          code,
          name: data.name,
          icon: data.icon,
          amount: Number(data.amount.toFixed(2)),
          percentage: totalIncome > 0 ? Number(((data.amount / totalIncome) * 100).toFixed(1)) : 0,
        })).sort((a, b) => b.amount - a.amount);

        resolve({
          totalExpense: Number(totalExpense.toFixed(2)),
          totalIncome: Number(totalIncome.toFixed(2)),
          budget: settings.monthlyBudget,
          categoryExpenses,
          categoryIncomes,
        });
      }, 250);
    });
  },

  // Get daily spending trend for bar chart (YYYY-MM)
  getDailyTrend(month: string): Promise<{ date: string; day: string; expense: number; income: number }[]> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const bills = loadBills().filter((b) => b.date.startsWith(month));
        const [yearStr, monthStr] = month.split('-');
        const year = parseInt(yearStr, 10);
        const monthIndex = parseInt(monthStr, 10) - 1;

        // Find how many days are in this month
        const daysInMonth = new Date(year, monthIndex + 1, 0).getDate();
        const trendData: { date: string; day: string; expense: number; income: number }[] = [];

        for (let i = 1; i <= daysInMonth; i++) {
          const dayStr = i.toString().padStart(2, '0');
          const fullDate = `${yearStr}-${monthStr}-${dayStr}`;
          
          trendData.push({
            date: fullDate,
            day: `${i}日`,
            expense: 0,
            income: 0,
          });
        }

        bills.forEach((b) => {
          const billDay = parseInt(b.date.split('-')[2], 10);
          if (billDay >= 1 && billDay <= daysInMonth) {
            const index = billDay - 1;
            if (b.type === 'expense') {
              trendData[index].expense += b.amount;
            } else {
              trendData[index].income += b.amount;
            }
          }
        });

        // Round numbers
        trendData.forEach((d) => {
          d.expense = Number(d.expense.toFixed(2));
          d.income = Number(d.income.toFixed(2));
        });

        resolve(trendData);
      }, 200);
    });
  },
};
